# Project Status

This file owns current build and branch status for this local source checkpoint.

| Field | Status |
| --- | --- |
| Repository | `LuvacZantor/zft-round-initiative` |
| Baseline | `main` commit `251a1dbe3e3aedd179b17d7582db183949cb840d`, initial README and MIT LICENSE |
| Runtime baseline | Delivered `13.0.0-dev.5` ZIP SHA-256 `05d7a2622d1a1c64c44dced01285c3417b9a284b6c617960e4c70ffff806827e` |
| Active source | Local, uncommitted dev.6 update; no source branch has been created remotely |
| Module | `zft-round-initiative` / `13.0.0-dev.6` |
| Target | Foundry V13 / D&D5e, explicitly requested November 22, 2026 |
| Evidence | Locally validated; see [acceptance plan](docs/TESTING.md) and [build record](docs/validation/build.json) |
| Actual live versions | Not inspected; record core/system/Midi-QOL/Carousel/Tools versions during testing |
| Stable module fallback | No accepted stable release. Previous test package: dev.5, with its taller embedded control strip; disable module for prior workflow |
| Branches | Remote `main` holds initial files only; proposed future development branch is `develop` |
| GitHub writes | Not authorized or performed; no push, merge, tag or release |
| Next action | Owner tests the complete ZIP in a copied V13 world, then queues findings |

Preserve the original macro files and MIT license, native Combat/Combatant IDs, actor data, existing turn integrations, and the GM-only world history journals. User advances the round in Foundry; module operations must not modify `Combat.round` or the world clock.

Owner deferred the movement-history check; no new clearing behavior is included in dev.6.

Owner screenshots show the dev.5 character rows restored to approximately the pre-module row height, compared with the oversized dev.4 arrow button. No native combatant-row, portrait, timing-label or effects sizing is changed in dev.6. Only the module-owned embedded strip and its controls are compacted. Browser/CSS cascade acceptance remains pending.
