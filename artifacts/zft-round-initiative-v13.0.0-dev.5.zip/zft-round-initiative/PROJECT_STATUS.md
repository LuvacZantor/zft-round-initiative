# Project Status

This file owns current build and branch status for this local source checkpoint.

| Field | Status |
| --- | --- |
| Repository | `LuvacZantor/zft-round-initiative` |
| Baseline | `main` commit `251a1dbe3e3aedd179b17d7582db183949cb840d`, initial README and MIT LICENSE |
| Runtime baseline | Delivered `13.0.0-dev.4` ZIP SHA-256 `e63ee91120e92a675b812498648ec7ac6c10f72852a4863541b64ce713bd189b` |
| Active source | Local, uncommitted dev.5 update; no source branch has been created remotely |
| Module | `zft-round-initiative` / `13.0.0-dev.5` |
| Target | Foundry V13 / D&D5e, explicitly requested November 22, 2026 |
| Evidence | Locally validated; see [acceptance plan](docs/TESTING.md) and [build record](docs/validation/build.json) |
| Actual live versions | Not inspected; record core/system/Midi-QOL/Carousel/Tools versions during testing |
| Stable module fallback | No accepted stable release. Previous test package: dev.4, with its footer strip and tall row-button issue; disable module for prior workflow |
| Branches | Remote `main` holds initial files only; proposed future development branch is `develop` |
| GitHub writes | Not authorized or performed; no push, merge, tag or release |
| Next action | Owner tests the complete ZIP in a copied V13 world, then queues findings |

Preserve the original macro files and MIT license, native Combat/Combatant IDs, actor data, existing turn integrations, and the GM-only world history journals. User advances the round in Foundry; module operations must not modify `Combat.round` or the world clock.

Owner deferred the movement-history check; no new clearing behavior is included in dev.5.
